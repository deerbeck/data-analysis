# Anleitung zum Ausfüllen

1.  **Bitte das Format der Datei unverändert lassen**, insbesondere

    - Überschrift-Zeilen, die mit "#" beginnen, unverändert lassen,
    - Leerzeilenn unverändert lassen.

2.  Bestätigung am Ende **LESEN** und unverändert lassen.

3.  "Teamname" durch einen selbst gewählten Teamnamen ersetzen.

4.  Namen im Format "Nachname(n), Vorname(n)" eintragen.

    **ACHTUNG**:

    -   **NACHname** zuerst.
    -   Danach ein Komma zur Unterscheidung!

    Bitte arbeiten Sie in 2-er Teams zusammen.
    Sollte es Ihnen nicht gelingen eine Partnerin oder einen Partner zu finden,
    melden Sie sich bei mir, möglichst **WÄHREND** der Veranstaltung.
    Sollten Sie trotzdem alleine arbeiten und abgeben wollen,
    tragen Sie unter "Teilnehmer:in 2" nur LEER (in Großbuchstaben) ein.

5.  Email bzw. LEER (in Großbuchstaben) eintragen.

6.  Bitte geben Sie Ihre Quellen an.

7.  **BITTE ÜBERPRÜFEN** Sie alle Daten noch einmal,
    denn sie sind wichtig für die Generierung der Aufgaben
    und die spätere Bewertung

# Daten zur Abgabe und zur Aufgabengenerierung

## Team
Die zwei lustigen Drei

## Teilnehmer:in 1
Hirschbeck, Johannes

## Teilnehmer:in 2
Garcia Mejia, Jorge Ivan

## Email 1
jhirschb@hm.edu

## Email 2
jorge_ivan.garcia_mejia@hm.edu

## Quellen
"https://www.w3schools.com/python/default.asp"
"P1.pdf"
"Datenanalyse Skript"

## Bemerkungen
Was Sie sonst noch los werden wollen.

## Bestätigung
Ich / wir bestätigen, dass wir nur die angegebenen Quellen benutzt haben.


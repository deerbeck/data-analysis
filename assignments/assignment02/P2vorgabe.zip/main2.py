#!/usr/bin/env python3
# -*- coding: utf-8 -*-



import numpy as np
import matplotlib.pyplot as plt



dummy = 0
def adummy(n):
    return np.zeros(n)



###   Thema: Bayessche Formel

def Bayes_Formel(P_B_A, P_A, P_B):
    return dummy

def totale_Wahrscheinlichkeit(P_B_Ai, P_Ai):
    return dummy

def Test(Korrektheit, a_priori_Wahrscheinlichkeit):
    P_T  = dummy
    P_K_T = dummy
    return P_T, P_K_T

def Aufgabe_Bayes():
    """Ausgabe der Werte von Beispiel 2.3.10 und Aufgabe 2.3
    sowie plotten der a-posteriori-Wahrscheinlich gegen die a-priori-Wahrscheinlichkeit."""
    
    # Hier Ausgabe der Werte
    pass
    
    # Die Plotbefehle könnten folgendermaßen aussehen:
    # a_priori_Wahrscheinlichkeiten = np.linspace(0, 1, 1000)
    # ...
    # plt.plot(a_priori_Wahrscheinlichkeiten, a_priori_Wahrscheinlichkeiten, label='a priori')
    # plt.plot(a_priori_Wahrscheinlichkeiten, T, label='total')
    # plt.plot(a_priori_Wahrscheinlichkeiten, P_K_T, label='a posteriori')
    # plt.legend()
    # plt.show()



###   Thema: Verteilungen

rng = np.random.default_rng()

def normal_10_3(rng, n):
    return adummy(n)

def uniform_100_10(rng, n):
    return adummy(n)

def mixed_normal(rng, n, M, S, P):
    """M, S, P sind Listen gleicher Länge von Mittelwerten, Standardabweichungen
    und Wahrscheinlichkeiten. Siehe unten für Argumente und Benutzung von mixed_normal(...)"""
    return adummy(n)

def mixed_normal_2(rng, n):
    data = [(-4, 4), (2, 4), (0.5, 0.5)]
    return mixed_normal(rng, n, *data)

def mixed_normal_3(rng, n):
    data = [(-5, 0, 5), (1, 1, 1), (1/3, 1/3, 1/3)]
    return mixed_normal(rng, n, *data)

def mixed_normal_11(rng, n):
    M = np.linspace(0, 100, 11)
    S = np.linspace(2, 5, 11)
    P = np.array([50, 41, 34, 29, 26, 25, 26, 29, 34, 41, 50]) / 385
    return mixed_normal(rng, n, M, S, P)

distributions = [
    normal_10_3,
    uniform_100_10,
    mixed_normal_2,
    mixed_normal_3,
    mixed_normal_11,
    ]

def Aufgabe_Verteilungen():
    """Plotten von Histogrammen für die Verteilungen."""
    n, bins = 10**6, 100
    for distr in distributions:
        X = distr(rng, n)
        plt.hist(X, bins=bins, density=True, histtype='stepfilled', label=distr.__name__)
        plt.legend()
        plt.show()
        


###   Thema: Gesetz der großen Zahlen (GdgZ)

def rel_variance_of_mean(rng, distr, no_samples, no_runs):
    X = distr(rng, no_samples*no_runs).reshape(no_samples, no_runs)
    # Hier Berechnunge der Mittelwerte über die Spalten von X
    # und Berechnung der Varianzen
    return dummy

def Aufgabe_GdgZ():
    """Hier sollen die relativen Varianzen in Abhängigkeit von der Anzahl der 
    Samples (no_samples) geplottet werden."""
    no_runs = 100
    # Als Plotbefehle könnten Sie folgendes nutzen:
    # for distr in distributions:
    #     ...
    #     plt.plot(No_samples, Variances, label=distr.__name__, alpha=0.5)
    # plt.legend()
    # plt.show()



###   Thema: Zentraler Grenzwertsatz (ZGWS)

def centralized_sample(rng, distr, no_samples, no_runs):
    X = distr(rng, no_samples*no_runs).reshape(no_samples, no_runs)
    # Berechnung der zentralisierten Zufallsvariable aus den Spalten von X
    return adummy(no_runs)

def Aufgabe_ZGWS():
    no_runs = 10**6
    n = 3
    N = np.arange(1, n+1)
    bins = 100
    for distr in distributions:
        for n in N:
            X = centralized_sample(rng, distr, n, no_runs)
            plt.hist(X, bins=bins, density=True, histtype='stepfilled', alpha=0.6, label=distr.__name__ + f', n={n}');
        plt.legend()
        plt.show()
        


###   Ausführen der Bearbeitungen
        
# Aufgabe_Bayes()
# Aufgabe_Verteilungen()
# Aufgabe_GdgZ()
# Aufgabe_ZGWS()